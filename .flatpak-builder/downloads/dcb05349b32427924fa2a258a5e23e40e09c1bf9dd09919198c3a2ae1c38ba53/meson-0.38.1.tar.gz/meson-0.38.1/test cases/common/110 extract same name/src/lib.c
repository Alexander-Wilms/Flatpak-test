int func2() {
    return 42;
}
