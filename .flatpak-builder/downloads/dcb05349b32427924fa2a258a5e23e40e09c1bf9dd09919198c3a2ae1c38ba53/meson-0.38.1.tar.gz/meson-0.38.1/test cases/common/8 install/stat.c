int func() { return 933; }
