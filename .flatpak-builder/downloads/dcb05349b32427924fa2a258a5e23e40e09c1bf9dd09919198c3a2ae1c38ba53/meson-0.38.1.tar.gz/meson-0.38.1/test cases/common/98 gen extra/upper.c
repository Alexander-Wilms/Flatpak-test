int BOB_MCBOB();

int main(int argc, char **argv) {
    return BOB_MCBOB();
}
