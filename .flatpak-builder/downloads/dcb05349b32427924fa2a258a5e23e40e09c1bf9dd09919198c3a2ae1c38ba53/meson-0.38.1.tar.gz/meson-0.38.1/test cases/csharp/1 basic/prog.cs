using System;
 
public class Prog {
    static public void Main () {
        Console.WriteLine("C# is working.");
    }
}
