using System;

public class Helper {
    public void print() {
        Console.WriteLine("Library class called.");
    }
}
