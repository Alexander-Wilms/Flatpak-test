using System;

public class Prog {
    static public void Main () {
        Helper h = new Helper();
        h.print();
    }
}
