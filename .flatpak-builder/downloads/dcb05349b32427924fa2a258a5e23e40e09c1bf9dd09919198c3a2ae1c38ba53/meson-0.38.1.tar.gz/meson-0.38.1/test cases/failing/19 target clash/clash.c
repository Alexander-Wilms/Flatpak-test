#include<stdio.h>

int main(int argc, char **argv) {
    printf("Clash 2.\n");
    return 0;
}
