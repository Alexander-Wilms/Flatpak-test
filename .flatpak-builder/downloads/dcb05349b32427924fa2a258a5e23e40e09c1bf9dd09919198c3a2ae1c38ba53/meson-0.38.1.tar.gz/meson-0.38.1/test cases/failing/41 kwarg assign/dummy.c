const char* dummy() {
    return "I do nothing.";
}
