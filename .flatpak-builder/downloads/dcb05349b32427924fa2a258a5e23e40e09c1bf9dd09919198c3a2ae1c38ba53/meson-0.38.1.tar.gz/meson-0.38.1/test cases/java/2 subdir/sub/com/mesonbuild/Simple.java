package com.mesonbuild;

class Simple {
    public static void main(String [] args) {
        TextPrinter t = new TextPrinter("Printing from Java.");
        t.print();
    }
}
