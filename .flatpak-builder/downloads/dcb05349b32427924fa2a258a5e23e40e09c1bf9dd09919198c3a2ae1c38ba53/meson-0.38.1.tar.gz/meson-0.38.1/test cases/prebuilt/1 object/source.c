/*
 * Compile this manually on new platforms and add the
 * object file to revision control and Meson configuration.
 */

int func() {
    return 42;
}
