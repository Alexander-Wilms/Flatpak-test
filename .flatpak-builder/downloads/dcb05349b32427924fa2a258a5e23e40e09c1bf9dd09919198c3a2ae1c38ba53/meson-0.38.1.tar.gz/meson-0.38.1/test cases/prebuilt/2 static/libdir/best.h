#pragma once

const char *msg();
