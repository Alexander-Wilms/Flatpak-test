#include <glib-object.h>

#pragma once

int bar_return_success(void);
