#include <glib-object.h>

#pragma once

int foo_return_success(void);
