int somedllfunc();

int main(int argc, char **argv) {
    return somedllfunc() == 42 ? 0 : 1;
}
