#ifdef _WIN32
__declspec(dllexport)
#endif
int myFunc() {
    return 55;
}
